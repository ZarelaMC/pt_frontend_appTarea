#!/bin/bash
echo "🚀 Aplicación Angular desplegada correctamente en EC2"
