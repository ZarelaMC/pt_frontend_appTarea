#!/bin/bash
echo "✅ Archivos copiados correctamente"
